package me.tzipi.duels;

import me.tzipi.duels.SQL.MySQL;
import me.tzipi.duels.SQL.SQLGetter;
import me.tzipi.duels.commands.*;
import me.tzipi.duels.listeners.*;
import me.tzipi.duels.manager.GameManager;
import me.tzipi.duels.scoreboard.HubScoreboard;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;

import java.sql.SQLException;


public class Main extends JavaPlugin implements Listener {
    public MySQL SQL;
    public SQLGetter sqlGetter;
    private GameManager gameManager;
    private HubScoreboard hubScoreboard;
    @Override
    public void onEnable() {
        super.onEnable();
        this.SQL = new MySQL();
        this.sqlGetter = new SQLGetter(this);
        this.hubScoreboard = new HubScoreboard(this, sqlGetter);
        try{
            SQL.connect();
        }catch (ClassNotFoundException  | SQLException e) {
            Bukkit.getLogger().info(ChatColor.RED  + "Database not connected");
        }
        if(SQL.isConnected()) {
            Bukkit.getLogger().info(ChatColor.GREEN + "Database connected!");
           this.getCommand("addpoint").setExecutor(new AddPoint(sqlGetter));
            sqlGetter.createTable();
           this.getServer().getPluginManager().registerEvents(new HubScoreboard(this, sqlGetter), this);
        }
        Bukkit.getLogger().info(ChatColor.GREEN + "Duels has been enabled");
        this.gameManager = new GameManager(this);
        this.getConfig().options().copyDefaults(true);
        this.saveConfig();
        getServer().getPluginManager().registerEvents(new BlockBreakListener(this), this);
        getCommand("join").setExecutor(new Join(gameManager));
        getServer().getPluginManager().registerEvents(new LastHitEvent(gameManager, sqlGetter), this);
        getServer().getPluginManager().registerEvents(new QuitEvent(sqlGetter,gameManager,this) ,this);
        getServer().getPluginManager().registerEvents(new EntityDamageByEntity(gameManager),this);
        getServer().getPluginManager().registerEvents(new EntityHit(gameManager),this);
        if(!Bukkit.getOnlinePlayers().isEmpty()) {
            for(Player online : Bukkit.getOnlinePlayers()) {
                hubScoreboard.createBoard(online);

            }
        }
    }
    @Override
    public void onDisable() {
        SQL.disconnect();
        super.onDisable();
        Bukkit.getLogger().info(ChatColor.DARK_RED + "Duels has been disabled");

    }

}
