package me.tzipi.duels.manager;

public enum GameState {
    LOBBY, STARTING, ACTIVE;

}
