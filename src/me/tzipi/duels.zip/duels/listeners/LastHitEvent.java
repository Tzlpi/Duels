package me.tzipi.duels.listeners;

import me.tzipi.duels.SQL.SQLGetter;
import me.tzipi.duels.manager.GameManager;
import me.tzipi.duels.manager.GameState;
import me.tzipi.duels.scoreboard.HubScoreboard;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class LastHitEvent implements Listener {
    private HubScoreboard hubScoreboard;
    private final SQLGetter sqlGetter;
    private final GameManager gameManager;
    public LastHitEvent(GameManager gameManager, SQLGetter sqlGetter) {
        this.gameManager = gameManager;
        this.sqlGetter = sqlGetter;
    }

    @EventHandler
    public void lastHit(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player) {
            Player player = (Player) e.getEntity();
            Player killer = ((Player) e.getEntity()).getKiller();
            if (e.getFinalDamage() >= player.getHealth()) {
                if (this.gameManager.inGame.contains(player)) {
                    this.gameManager.inGame.remove(player);
                    this.gameManager.inGame.remove(killer);

                    this.gameManager.notInGame.add(player);
                    this.gameManager.notInGame.add(killer);

                    Bukkit.broadcastMessage(ChatColor.RED + player.getName() + " has lost.");
                    Bukkit.broadcastMessage(ChatColor.RED + killer.getName() + " has won");
                    player.setHealth(20);
                    killer.setHealth(20);
                    killer.getInventory().clear();
                    player.getInventory().clear();
                    killer.getInventory().setArmorContents(null);
                    player.getInventory().setArmorContents(null);
                    sqlGetter.addPoints(killer.getUniqueId(),1 );
                    this.gameManager.setGameState(GameState.LOBBY);

                    e.setCancelled(true);

                }

            }
        }
    }
}
