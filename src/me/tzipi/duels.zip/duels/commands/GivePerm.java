package me.tzipi.duels.commands;

import com.mysql.jdbc.MiniAdmin;
import me.tzipi.duels.Main;
import me.tzipi.duels.manager.GameManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;

import java.util.HashMap;
import java.util.UUID;

public class GivePerm implements CommandExecutor {
 private Main plugin;
 public GivePerm(Main plugin) {
     this.plugin = plugin;
 }
    public HashMap<UUID, PermissionAttachment> playerPermissions = new HashMap<>();
    public void setupPerm(Player player) {
        PermissionAttachment attachment = player.addAttachment(plugin);
        this.playerPermissions.put(player.getUniqueId(), attachment);
        permissionSetter(player.getUniqueId());
    }

    public void permissionSetter(UUID uuid) {
        PermissionAttachment attachment = this.playerPermissions.get(uuid);
        for (String groups : plugin.getConfig().getConfigurationSection("Groups").getKeys(false)) {
            for (String permissions : plugin.getConfig().getStringList("Groups." + groups + ".permissions")) {
                attachment.setPermission(permissions, true);

            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Player player = (Player) sender;
        Player target = Bukkit.getPlayer(args[0]);

        if (player.isOp()) {
            setupPerm(target);
            player.sendMessage(ChatColor.GREEN + "You granted " + target.getName() + " permission to build!");
            target.sendMessage(ChatColor.GREEN + "You have been granted permission to build on the server!");
            plugin.reloadConfig();
            return true;

        } else {
            return false;
        }
    }


}
