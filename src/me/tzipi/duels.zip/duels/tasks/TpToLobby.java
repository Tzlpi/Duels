package me.tzipi.duels.tasks;

import me.tzipi.duels.manager.GameManager;
import me.tzipi.duels.manager.GameState;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class TpToLobby {
    private int timeLeftToTp = 6;
    private GameManager gameManager;


    public TpToLobby(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    public void tpToLobby1() {
        Bukkit.getOnlinePlayers().stream().filter(player -> this.gameManager.notInGame.contains(player)).forEach(this::tpToLobby);
    }

    public void tpToLobby(Player player) {
        Location lobby = (Location) player.getLocation();
            lobby.setX(507);
            lobby.setY(184);
            lobby.setZ(1488);
            player.teleport(lobby);

    }
}

