package me.tzipi.duels.tasks;

import me.tzipi.duels.manager.GameManager;
import me.tzipi.duels.manager.GameState;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.scheduler.BukkitRunnable;

public class CountDownStart extends BukkitRunnable {
    private GameManager gameManager;
    public CountDownStart(GameManager gameManager){
        this.gameManager = gameManager;
    }
    private int timeLeft = 6;
    @Override
    public void run() {
        timeLeft--;
        if(timeLeft <= 0) {
            cancel();
            gameManager.setGameState(GameState.ACTIVE);
            return;
        }
        Bukkit.broadcastMessage(ChatColor.YELLOW  + "The game starts in " + ChatColor.RED + timeLeft + ChatColor.YELLOW + " seconds!");


    }
}
